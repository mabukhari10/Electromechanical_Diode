clear all
clc

global w elam elam1 
w=2*1000;
s=1*500;
elam=0.06*0;
elam1=0.06;
%maxx=20000;

    maxx=2/1;

wd=1000;

step=0.00025;
tspan=0:step:maxx;

z0=zeros(4*s,1);
opts = odeset('RelTol',1e-8,'AbsTol',1e-8);
[t,z]=ode45(@one_sys_non_JSV,tspan,z0,opts);

% powerin=z(:,5).^2/R;
% powerout=z(:,2500).^2/R;
% Ein=trapz(t(1:6100)/1000,powerin(1:6100));
% Eout=trapz(t(1:6100)/1000,powerout(1:6100));

% Pin=(z(:,1)-1*z(:,6)+0.06*(z(:,1)-1*z(:,6)).^3).*z(:,2);
% Pout=1.2939*(z(:,2496)-1*z(:,2491)).*z(:,2497);
% Ei=trapz(t/1000,Pin);
% Eo=trapz(t/1000,Pout);
