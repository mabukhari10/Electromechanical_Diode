clear all
clc

global w elam elam1  theta R Cp
MM=permn([1 2 3],2);

for Prob=1:3:7
    Prob
    close all
    MM1=MM(Prob,:);
    
    
    if MM1(1)==1
        elam=0;
        fig_1='linear_';
    elseif MM1(1)==2;
        elam=0.03;
        fig_1='hard_03';
    else
        elam=-0.03;
        fig_1='soft_03';
    end
    
    if MM1(2)==1
        elam1=0;
        fig_2='linear_';
    elseif MM1(2)==2;
        elam1=0.03;
        fig_2='hard_03';
    else
        elam1=-0.03;
        fig_2='soft_03';
    end
    
    
    
wav=0;
filename='G:\My Drive\Non_energy_harvesting\R1\Figures_FFT\strong_e-8\Re2\Nonlinear_Fig';

theta=171e-12*1e0;
Cp=13.3e-9*1;
R=1e7;
for k= 7*pi/9%0.01:0.05:pi;

s=500;
%maxx=20000;

    maxx=2000/1*3;

wd=1000;

step=0.25;
tspan=0:step:maxx;
wn=1000;
%%
K=k;
k1=wd^2;
kb=wd/wn;

alpha1=theta/k1;
alpha2=R*Cp/wn;
alpha3=R*theta*wn;
Omega=wn/wd;

ccc1=2-2*cos(k);
ccc=(1-cos(k))^2;
a=-alpha2*Omega^2;
b=-i*Omega^2;
c=alpha2+alpha1*alpha3+ccc1*alpha2*Omega^2+kb*alpha2*Omega^2+...
    kb*alpha1*alpha3*Omega^2;
d=i+i*ccc1*Omega^2+i*kb*Omega^2;
e= -ccc1*alpha2-ccc1*alpha1*alpha3;
f=-i*ccc1;

P=[a, b, c, d, e, f];
omega=sort(real(roots(P)));
w=real(omega(5));
%%
z0=zeros(5*s,1);
kw1=-1+(k1.^2.*w.^4.*wn.^4.*(1+Cp.^2.*R.^2.*w.^2.*wn.^2).*(R.^2.* ...
  theta.^4.*w.^2.*wd.^4.*wn.^2+2.*Cp.*k1.*R.^2.*theta.^2.*w.^2.* ...
  wd.^2.*wn.^2.*(wd.^2+(-1).*w.^2.*wn.^2)+k1.^2.*(wd.^2+(-1).*w.^2.* ...
  wn.^2).^2.*(1+Cp.^2.*R.^2.*w.^2.*wn.^2)).^(-1)).^(1/2);
kw1= wd^2/(wd^2-w^2*wn^2);
varphi=R*theta*w/sqrt(1/wn^2+(R*Cp*w)^2);
Ncy=7;
A=1;%sqrt(0.1);
for m=1:s
   z0(5*m-4,1)=A/2*(heaviside(m-1)-heaviside(m-1-Ncy*2*pi/k))*...
       (1-cos(m*k/Ncy))*sin(m*k);
   z0(5*m-3,1)=A/2*(heaviside(m-1)-heaviside(m-1-Ncy*2*pi/k))*...
       (-wd/wn*w/Ncy*sin(m*k/Ncy)*sin(m*k)-wd/wn*w*(1-cos(m*k/Ncy))*cos(m*k));
   z0(5*m-2,1)=kw1*z0(5*m-4,1);
   z0(5*m-1,1)=kw1*z0(5*m-3,1);
   z0(5*m,1)=kw1*varphi*z0(5*m-4,1);
end
tic
opts = odeset('RelTol',1e-8,'AbsTol',1e-8);
[t,z]=ode45(@one_sys_non_res_lab,tspan,z0,opts);

filezname=[filename,'\time_matrix\timeresponse',num2str(k),'.mat'];
% save(filezname,'z');

ss=0;
zz=zeros(length(tspan),s);
for sss=1:5:s*5
    ss=ss+1;
    zz(:,ss)=z(:,sss);
    zzabs(:,ss)=z(:,sss+2)-z(:,sss);
    zzpower(:,ss)=z(:,sss+4);
end
filezzname=[filename,'\displacement_only\displacement',num2str(k),'.mat'];
% save(filezzname,'zz');
zz1=zz;
zz= imresize(zz,[length(z) 1000],'lanczos2');
zzabs1= imresize(zzabs,[length(z) 1000],'lanczos2');
zzpower1= imresize(zzpower,[length(z) 1000],'lanczos2');
t=t;%(3*maxx/step/4:end);
T=t(2)-t(1);
Fs=1/T;
L=(length(t)-1)*2;
Fn=2;
Ln=s*4*2;
f = Fs*(0:floor(L/2)-1)/L;
fn=Fn*(0:floor(Ln/2/2)-1)/Ln;

%%
% for jj=1:s
% P3=angle(fft(z(3*maxx/step/4:end,jj*6-5))/L);
% P12 = abs(fft(z(3*maxx/step/4:end,jj*6-5))/L);
% P11 = P12(1:floor(L/2+1));
% P11(1:end-1) = 2*P11(1:end-1);
% file1name=[filename,'\fft1\freq_resp_',num2str(jj),'_',num2str(k),'.mat'];
% save(file1name,'f','P11','P3');
% end
%%C:\Data
Y=fft2(zz,L,Ln);
Y2=fft2(zzabs1,L,Ln);
Y3=fft2(zzpower1,L,Ln);
YY=2*Y(2:floor(L/2+1),2:floor(Ln/2+1));
YYabs=2*Y2(2:floor(L/2+1),2:floor(Ln/2+1));
YYpower=2*Y3(2:floor(L/2+1),2:floor(Ln/2+1));
YY1=YY(:,1:1000);
YY2=(YY(:,1001:end))';
YY2=(flip(YY2,1))';
YY=YY1+YY2;


YYabs1=YYabs(:,1:1000);
YYabs2=(YYabs(:,1001:end))';
YYabs2=(flip(YYabs2,1))';
YYabs=YYabs1+YYabs2;

YYpower1=YYpower(:,1:1000);
YYpower2=(YYpower(:,1001:end))';
YYpower2=(flip(YYpower2,1))';
YYpower=YYpower1+YYpower2;

fileYname=[filename,'\2dfft\freq_resp_',num2str(k),'.mat'];
% save(fileYname,'f','fn','YY');
[M,I] = max(abs(YY(:)));

[I_row, I_col] = ind2sub(size(abs(YY)),I);

wav=wav+1
%YYY(wav,:,:)=YY;
%mm(wav,:,:)=zz;
nonfreq(wav)=f(I_row)*2*pi;
nonwav(wav)=fn(I_col)*2*pi;
freq(wav)=w;
toc
end
% save([filename,'\two_resonator1.0_(0.06)_0.1_0.6_full.mat'],'nonwav','nonfreq','freq')

fig_name=['G:\My Drive\Non_energy_harvesting\R1\Figures_FFT\Data\R107\Nonlinear_Fig\upper_3\',fig_1,fig_2,'2_'];

%%
figure;
xxpacket=imresize((1:500)',2,'lanczos2');
p1=plot(zzpower(2,:),'LineWidth',1);
set(p1,'Color','blue')
set(gca,'TickLabelInterpreter','latex')
xlabel('cell', 'FontSize', 14,'interpreter','latex')
ylabel('Voltage', 'FontSize', 14,'interpreter','latex')
hold on
p4=plot(zzpower((end-1)/6,:),'LineWidth',1);
set(p4,'Color','red')
p2=plot(zzpower(1*(end-1)/3,:),'LineWidth',1);
set(p2,'Color','black')
leg1=legend('Input' ,'Mid-sim', 'End-sim');
set(leg1,'Interpreter','latex');
 savefig([fig_name,num2str(k),'wavepacket_power.fig'])
%saveas(gcf,[fig_name,num2str(k),'wavepacket.eps'],'epsc')

 figure; colormap(jet); fig2=contour(2*pi*fn,2*pi*f,abs(YYpower)/M);
 set(gca,'TickLabelInterpreter','latex')
 xlabel('k', 'FontSize', 14,'interpreter','latex')
ylabel('$\Omega$', 'FontSize', 14,'interpreter','latex')
colorbar('TickLabelInterpreter','latex');
 savefig([fig_name,num2str(k),'contour_power.fig'])
%saveas(fig2,[fig_name,num2str(k),'contour.eps'],'epsc')


figure;colormap(jet);
fig3=imagesc(2*pi*fn,2*pi*f,abs(YYpower)/M);
axis xy; 
set(gca,'TickLabelInterpreter','latex')
xlabel('$k$', 'FontSize', 14,'interpreter','latex')
ylabel('$\Omega$', 'FontSize', 14,'interpreter','latex')
colorbar('TickLabelInterpreter','latex');
 savefig([fig_name,num2str(k),'2dfft_power.fig'])


wftrans1(zzpower((end-1)/3,:)+zzpower(1,:),0.04,0.5,10000,'hann','log')
%caxis([-20 0])

hold on;
x=0:500;
y=1.86;
plot(x,y*ones(size(x)),'LineWidth',2,'LineStyle','--',...
'Color',[0.952941179275513 0.87058824300766 0.733333349227905])

hold on;
x=0:500;
y=3;
plot(x,y*ones(size(x)),'LineWidth',2,'LineStyle','--',...
'Color',[0.952941179275513 0.87058824300766 0.733333349227905])


 savefig([fig_name,num2str(k),'STFT_power_2.fig'])




%%
figure;
xxpacket=imresize((1:500)',2,'lanczos2');
p1=plot(zz1(2,:),'LineWidth',1);
set(p1,'Color','blue')
set(gca,'TickLabelInterpreter','latex')
xlabel('cell', 'FontSize', 14,'interpreter','latex')
ylabel('Amplitude', 'FontSize', 14,'interpreter','latex')
hold on
p4=plot(zz1((end-1)/6,:),'LineWidth',1);
set(p4,'Color','red')
p2=plot(zz1((end-1)/3,:),'LineWidth',1);
set(p2,'Color','black')
leg1=legend('Input' ,'Mid-sim', 'End-sim');
set(leg1,'Interpreter','latex');
 savefig([fig_name,num2str(k),'wavepacket_dis.fig'])
%saveas(gcf,[fig_name,num2str(k),'wavepacket.eps'],'epsc')

 figure; colormap(jet); fig2=contour(2*pi*fn,2*pi*f,abs(YY)/M);
 set(gca,'TickLabelInterpreter','latex')
 xlabel('k', 'FontSize', 14,'interpreter','latex')
ylabel('$\Omega$', 'FontSize', 14,'interpreter','latex')
colorbar('TickLabelInterpreter','latex');
 savefig([fig_name,num2str(k),'contour_dis.fig'])
%saveas(fig2,[fig_name,num2str(k),'contour.eps'],'epsc')


figure;colormap(jet);
fig3=imagesc(2*pi*fn,2*pi*f,abs(YY)/M);
axis xy; 
set(gca,'TickLabelInterpreter','latex')
xlabel('$k$', 'FontSize', 14,'interpreter','latex')
ylabel('$\Omega$', 'FontSize', 14,'interpreter','latex')
colorbar('TickLabelInterpreter','latex');
 savefig([fig_name,num2str(k),'2dfft_dis.fig'])


wftrans1(zz1((end-1)/3,:)+zz1(1,:),0.04,0.5,10000,'hann','log')
%caxis([-20 0])

hold on;
x=0:500;
y=1.86;
plot(x,y*ones(size(x)),'LineWidth',2,'LineStyle','--',...
'Color',[0.952941179275513 0.87058824300766 0.733333349227905])

hold on;
x=0:500;
y=3;
plot(x,y*ones(size(x)),'LineWidth',2,'LineStyle','--',...
'Color',[0.952941179275513 0.87058824300766 0.733333349227905])


 savefig([fig_name,num2str(k),'STFT_dis_2.fig'])
end