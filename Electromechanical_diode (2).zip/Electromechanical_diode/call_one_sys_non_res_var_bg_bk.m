clear all
clc
R=1e7;
i1=0;
tic
for kr1b= 0.5:0.01:1.5
    i1=i1+1;
kr1(i1)=kr1b;%1.2939;
i2=0;
for kr2b=0.01:0.01:1
    i2=i2+1;
    
kr2(i2)=kr2b;%0.1643*1;

kb=kr2b/kr1b;
kbb(i2)=kb;
i3=0;
for ml2b=0.01:0.01:1
    i3=i3+1;
ml2(i3)=ml2b;%0.0397*1;

wn=1e3*sqrt(kr1b);
theta=171e-12;
Cp=13.3e-9;
wd=1e3*sqrt(kr2b/ml2b);
k1=wd^2*ml2b;%wn^2*1.2939;
ii=0;
for k=0:pi:pi
    ii=ii+1;
ccc=2-2*cos(k);
aa=R*Cp*k1*wn^4;
bb=i*k1*wn^2;
cc=-R*theta^2*wn-R*Cp*k1*wd^2*wn^2-R*Cp*ccc*wn^4*k1-R*kb*Cp*k1*wn^4;
dd=-i*k1*wd^2-i*ccc*k1*wn^2-i*kb*k1*wn^2;
ee= ccc*R*theta^2*wn+ccc*R*Cp*k1*wd^2*wn^2;
ff=i*ccc*k1*wd^2;
p=[aa,bb,cc,dd,ee,ff];
r(:,ii)=roots(p);
kk(ii)=k;
end
rr=sort(real(r))*wn/1000;
r_ac(i1,i2,i3)=rr(4,end);
r_op(i1,i2,i3)=rr(5,1);
end
end
end

up_limit=1.7;
i5=0;

for low_limit=1.41%:0.03:2.44;
    i5=i5+1
c=find(r_ac<low_limit+0.01&r_ac>low_limit);[a b d] = ind2sub(size(r_ac),c);
A=[a,b,d];
clear c;c=find(r_op<up_limit+0.01&r_op>up_limit);[a b d] = ind2sub(size(r_op),c);
B=[a,b,d];
[~,index_A,index_B] = intersect(A,B,'rows');
%%


clearvars kr1b kr2b ml2b w elam elam1 theta R Cp 
global w elam elam1  theta R Cp kr1b kr2b ml2b
R=1e7;
index=A(index_A,:);
kr1b=0.5+(index(20,1)-1)*0.01;
kr2b=0.01+(index(20,2)-1)*0.01;
ml2b=0.01+(index(20,3)-1)*0.01;

%%

theta=171e-8*1e0;
Cp=13.3e-9*1;
R=1e7;
s=500;
elam=0.06*0;
elam1=-0.03*1;
%maxx=20000;

    maxx=1600/1;

wd=1000;

step=0.25;
tspan=0:step:maxx;

z0=zeros(5*s,1);
opts = odeset('RelTol',1e-8,'AbsTol',1e-8);
i4=0;
for w=1.5%:0.05:2.44
    i4=i4+1;
[t,z]=ode45(@one_sys_non_res_var_bg_bk,tspan,z0,opts);

powerin=z(:,5).^2/R;
powerout=z(:,end).^2/R;
Ein(i5,i4)=trapz(t/1000,powerin);
Eout(i5,i4)=trapz(t/1000,powerout);

E_ratio(i5,i4)=Ein(i5,i4)/Eout(i5,i4);


end
end
figure
vmax=max(z(:,5));
plot(t,z(:,5)/vmax)
hold on
plot(t,z(:,end)/vmax)
set(gca,'TickLabelInterpreter','latex')
xlabel('time(ms)', 'FontSize', 20,'interpreter','latex')
ylabel('Normalized Voltage', 'FontSize', 14,'interpreter','latex')
toc
