function dz= one_sys_non_res_sweep(t,z)
global w elam elam1 elam2 theta Cp R
s=500;
m=1;
Ncy=60;
t
% wd=1000;
% wn=wd;
% k1=wd^2*m;
% k=k1;
% kb=1;
% k1=wd^2*1;
%f0=1;
%w=1.46;
%elam=0.06*1;
%elam1=0.06;
dz(5*s,1)=zeros;
Cmax=0.0;%2.75/1000;
c(1)=0;
for n=1:s
    c(n+1)=Cmax*(n/s)^3;
    if n==1
        
         kb=1;
wn=1e3;%*sqrt(1.2939);
wd=1e3;
k1=wn^2;
k=k1;
        
        
         dz(5*n-4)=z(5*n-3);
    dz(5*n-3)=-(z(5*n-4)-z(5*(n+1)-4)+elam*...
        ((z(5*n-4)-z(5*(n+1)-4))^3)+...
        kb*(z(5*n-4)-z(5*(n)-2))+c(n)*(z(5*n-3))+...
        c(n+1)*(z(5*n-3)-z(5*(n+1)-3))+theta/k*z(5*n)+...
        elam1*kb*(z(5*n-4)-z(5*n-2))^3)+0.5*(heaviside(t)-...
        heaviside(t-2*pi*wn/wd/w*Ncy)).*(1-cos(wd*w/wn/Ncy*t)).*sin(wd*w/wn*t);
    dz(5*n-2)=z(5*n-1);
    dz(5*n-1)=wn^2/wd^2*(z(5*n-4)-z(5*(n)-2)+elam1*(z(5*n-4)-...
        z(5*n-2))^3+theta/k1*z(5*n));
    dz(5*n)=1/R/Cp*(-z(5*n)/wn+R*theta*(z(5*n-3)-z(5*(n)-1)));
    elseif n<500
        
         kb=1;
wn=1e3;%*sqrt(1.2939);
wd=1e3;
k1=wn^2;
k=k1;
        
        
    dz(5*n-4)=z(5*n-3);
    dz(5*n-3)=-(2*z(5*n-4)-z(5*(n+1)-4)-z(5*(n-1)-4)+elam*...
        ((z(5*n-4)-z(5*(n+1)-4))^3+(z(5*n-4)-z(5*(n-1)-4))^3)+...
        kb*(z(5*n-4)-z(5*(n)-2))+c(n)*(z(5*n-3)-z(5*(n-1)-3))+...
        c(n+1)*(z(5*n-3)-z(5*(n+1)-3))+theta/k*z(5*n)+...
        elam1*kb*(z(5*n-4)-z(5*n-2))^3);
    dz(5*n-2)=z(5*n-1);
    dz(5*n-1)=wn^2/wd^2*(z(5*n-4)-z(5*(n)-2)+elam1*(z(5*n-4)-...
        z(5*n-2))^3+theta/k1*z(5*n));
    dz(5*n)=1/R/Cp*(-z(5*n)/wn+R*theta*(z(5*n-3)-z(5*(n)-1)));
   
    
    
    elseif n==s
        
       
wn=1e3;%*sqrt(1.2939);
wd=1e3;
% k=wn^2*1.2939;
% k1=wn^2*0.1643;
        dz(5*n-4)=z(5*n-3);
    dz(5*n-3)=-(1*(z(5*n-4)-z(5*(n-1)-4))+1*elam*...
        ((z(5*n-4))^3+(z(5*n-4)-z(5*(n-1)-4))^3)+...
        1*(z(5*n-4)-z(5*(n)-2))+c(n)*(z(5*n-3)-z(5*(n-1)-3))+...
        c(n+1)*(z(5*n-3))+theta/k*z(5*n)+1*elam1*kb*(z(5*n-4)-z(5*n-2))^3);
    dz(5*n-2)=z(5*n-1);
    dz(5*n-1)=wd^2/wn^2*(z(5*n-4)-z(5*(n)-2)+1*elam1*(z(5*n-4)-...
        z(5*n-2))^3+theta/k1*z(5*n));
    dz(5*n)=1/R/Cp*(-z(5*n)/wn+R*theta*(z(5*n-3)-z(5*(n)-1)));
    end
end
end 