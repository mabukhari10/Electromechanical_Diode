clearvars -except index_A index_B A
clc
R=1e7;
tic

index=A(index_A,:);
for is=1:length(index)
kr1b=0.5+(index(is,1)-1)*0.01;
kr2b=0.01+(index(is,2)-1)*0.01;
ml2b=0.01+(index(is,3)-1)*0.01;
kr1b1(is)=kr1b;
kr2b1(is)=kr2b;
ml2b1(is)=ml2b;

wn=1e3*sqrt(kr1b);
theta=171e-12;
Cp=13.3e-9;
kb=kr2b/kr1b;
wd=1e3*sqrt(kr2b/ml2b);
k1=wd^2*ml2b;%wn^2*1.2939;
ii=0;
for k=0:0.01:pi
    ii=ii+1;
ccc=2-2*cos(k);
aa=R*Cp*k1*wn^4;
bb=i*k1*wn^2;
cc=-R*theta^2*wn-R*Cp*k1*wd^2*wn^2-R*Cp*ccc*wn^4*k1-R*kb*Cp*k1*wn^4;
dd=-i*k1*wd^2-i*ccc*k1*wn^2-i*kb*k1*wn^2;
ee= ccc*R*theta^2*wn+ccc*R*Cp*k1*wd^2*wn^2;
ff=i*ccc*k1*wd^2;
p=[aa,bb,cc,dd,ee,ff];
r(:,ii)=roots(p);
kk(ii)=k;
end
rr=sort(real(r))*wn/1000;
% figure
% plot(rr(4,:))
hold on
plot(kk,rr(5,:))
end