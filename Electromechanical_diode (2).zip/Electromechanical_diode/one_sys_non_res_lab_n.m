function dz= one_sys_non_res_lab_n(t,z)
global w elam elam1 theta Cp R
s=500;
m=1;
Ncy=60;
t;

dz(5*s,1)=zeros;
Cmax=0;%2.75/1000;
c(1)=0;

         kb=1;
wn=1e3;%*sqrt(1.2939);
wd=1e3;
k1=wn^2;
k=k1;
kr1b=0.78;%1.5;%0.78;%1.2939;%0.64;%1;%1.2939;
kr2b=0.21;%0.37;%0.21;%0.1643;%0.19;%0.6;%0.1643;
ml2b=0.09;%0.17;%0.09;%0.0397;%0.07;%0.23;%0.0397;

for n=1:s
    c(n+1)=Cmax*(n/s)^3;
    if n==1
        
        
        
         dz(5*n-4)=z(5*n-3);
    dz(5*n-3)=-(z(5*n-4)-z(5*(n+1)-4)+elam*...
        ((z(5*n-4)-z(5*(n+1)-4))^3)+...
        kb*(z(5*n-4)-z(5*(n)-2))+c(n)*(z(5*n-3))+...
        c(n+1)*(z(5*n-3)-z(5*(n+1)-3))+theta/k*z(5*n)+...
        elam1*kb*(z(5*n-4)-z(5*n-2))^3)+1*0.5*(heaviside(t)-...
        heaviside(t-2*pi*wn/wd/w*Ncy)).*(1-cos(wd*w/wn/Ncy*t)).*sin(wd*w/wn*t);
    dz(5*n-2)=z(5*n-1);
    dz(5*n-1)=wn^2/wd^2*(z(5*n-4)-z(5*(n)-2)+elam1*(z(5*n-4)-...
        z(5*n-2))^3+theta/k1*z(5*n));
    dz(5*n)=1/R/Cp*(-z(5*n)/wn+R*theta*(z(5*n-3)-z(5*(n)-1)));
    elseif n<350
        
        
        
    dz(5*n-4)=z(5*n-3);
    dz(5*n-3)=-(2*z(5*n-4)-z(5*(n+1)-4)-z(5*(n-1)-4)+elam*...
        ((z(5*n-4)-z(5*(n+1)-4))^3+(z(5*n-4)-z(5*(n-1)-4))^3)+...
        kb*(z(5*n-4)-z(5*(n)-2))+c(n)*(z(5*n-3)-z(5*(n-1)-3))+...
        c(n+1)*(z(5*n-3)-z(5*(n+1)-3))+theta/k*z(5*n)+...
        elam1*kb*(z(5*n-4)-z(5*n-2))^3);
    dz(5*n-2)=z(5*n-1);
    dz(5*n-1)=wn^2/wd^2*(z(5*n-4)-z(5*(n)-2)+elam1*(z(5*n-4)-...
        z(5*n-2))^3+theta/k1*z(5*n));
    dz(5*n)=1/R/Cp*(-z(5*n)/wn+R*theta*(z(5*n-3)-z(5*(n)-1)));
    elseif n==350
      
    dz(5*n-4)=z(5*n-3);
    dz(5*n-3)=-(z(5*n-4)-z(5*(n+1)-4)+kr1b*(z(5*n-4)-z(5*(n-1)-4))+elam*...
        (0*(z(5*n-4)-z(5*(n+1)-4))^3+(z(5*n-4)-z(5*(n-1)-4))^3)+...
        kb*(z(5*n-4)-z(5*(n)-2))+c(n)*(z(5*n-3)-z(5*(n-1)-3))+...
        c(n+1)*(z(5*n-3)-z(5*(n+1)-3))+theta/k*z(5*n)+...
        elam1*kb*(z(5*n-4)-z(5*n-2))^3);
    dz(5*n-2)=z(5*n-1);
    dz(5*n-1)=wn^2/wd^2*(z(5*n-4)-z(5*(n)-2)+elam1*(z(5*n-4)-...
        z(5*n-2))^3+theta/k1*z(5*n));
    dz(5*n)=1/R/Cp*(-z(5*n)/wn+R*theta*(z(5*n-3)-z(5*(n)-1)));
    
    
    elseif n==s
        
       
        dz(5*n-4)=z(5*n-3);
    dz(5*n-3)=-(kr1b*(z(5*n-4)-z(5*(n-1)-4))+0*elam*...
        ((z(5*n-4))^3+(z(5*n-4)-z(5*(n-1)-4))^3)+...
        kr2b*(z(5*n-4)-z(5*(n)-2))+c(n)*(z(5*n-3)-z(5*(n-1)-3))+...
        c(n+1)*(z(5*n-3))+theta/k*z(5*n)+0*elam1*kb*(z(5*n-4)-z(5*n-2))^3)+0*0.5*(heaviside(t)-...
        heaviside(t-2*pi*wn/wd/w*Ncy)).*(1-cos(wd*w/wn/Ncy*t)).*sin(wd*w/wn*t);
    dz(5*n-2)=z(5*n-1);
    dz(5*n-1)=(kr2b/ml2b*(z(5*n-4)-z(5*(n)-2))+0*elam1*(z(5*n-4)-...
        z(5*n-2))^3+theta/k1*kb/ml2b*z(5*n));
    dz(5*n)=1/R/Cp*(-z(5*n)/wn+R*theta*(z(5*n-3)-z(5*(n)-1)));
    else
        
        
        
        dz(5*n-4)=z(5*n-3);
    dz(5*n-3)=-(kr1b*(2*z(5*n-4)-z(5*(n+1)-4)-z(5*(n-1)-4))+0*elam*...
        ((z(5*n-4)-z(5*(n+1)-4))^3+(z(5*n-4)-z(5*(n-1)-4))^3)+...
        kr2b*(z(5*n-4)-z(5*(n)-2))+c(n)*(z(5*n-3)-z(5*(n-1)-3))+...
        c(n+1)*(z(5*n-3)-z(5*(n+1)-3))+theta/k*z(5*n)+...
        0*elam1*kb*(z(5*n-4)-z(5*n-2))^3);
    dz(5*n-2)=z(5*n-1);
    dz(5*n-1)=(kr2b/ml2b*(z(5*n-4)-z(5*(n)-2))+0*elam1*(z(5*n-4)-...
        z(5*n-2))^3+theta/k1*kb/ml2b*z(5*n));
    dz(5*n)=1/R/Cp*(-z(5*n)/wn+R*theta*(z(5*n-3)-z(5*(n)-1)));
    end
end
end 