
clear all
clc
global w elam elam1  theta R Cp
filename='G:\My Drive\Non_energy_harvesting\Figures_FFT\R1e4';
s=500;
elam=0.0;
elam1=0.06;
theta=171e-12;
Cp=13.3e-9;
R=1e7;
wav=0;
for k=0.01%:0.05:pi%0.1:0.05:3.14;
    tic
clear zz1 zz
maxx=8000/1;
step=0.25*1;
tspan=0:step:maxx;

wd=1000;

K=k;
wn=1000;
K=k;
k1=wd^2;
kb=wd/wn;


ccc=2-2*cos(k);
a=R*Cp*k1*wn^4;;
b=i*k1*wn^2;;
c=-R*theta^2*wn-R*Cp*k1*wd^2*wn^2-R*Cp*ccc*wn^4*k1-R*kb*Cp*k1*wn^4;
d=-i*k1*wd^2-i*ccc*k1*wn^2-i*kb*k1*wn^2;
e= ccc*R*theta^2*wn+ccc*R*Cp*k1*wd^2*wn^2;
f=i*ccc*k1*wd^2;
P=[a, b, c, d, e, f];
omega=sort(real(roots(P)));
w=real(omega(4));

z0=zeros(5*s,1);
kw1=(k1.^2.*w.^4.*wn.^4.*(1+Cp.^2.*R.^2.*w.^2.*wn.^2).*(R.^2.* ...
  theta.^4.*w.^2.*wd.^4.*wn.^2+2.*Cp.*k1.*R.^2.*theta.^2.*w.^2.* ...
  wd.^2.*wn.^2.*(wd.^2+(-1).*w.^2.*wn.^2)+k1.^2.*(wd.^2+(-1).*w.^2.* ...
  wn.^2).^2.*(1+Cp.^2.*R.^2.*w.^2.*wn.^2)).^(-1)).^(1/2);
kw1=wd^2/(wd^2-w^2*wn^2);
kw2=0;
varphi=R*theta*w/sqrt(1/wn^2+(R*Cp*w)^2);
Ncy=7;
A=1;%sqrt(0.1);
for m=1:s
   z0(5*m-4,1)=A/2*(heaviside(m-1)-heaviside(m-1-Ncy*2*pi/k))*...
       (1-cos(m*k/Ncy))*sin(m*k);
   z0(5*m-3,1)=A/2*(heaviside(m-1)-heaviside(m-1-Ncy*2*pi/k))*...
       (-wd/wn*w/Ncy*sin(m*k/Ncy)*sin(m*k)-wd/wn*w*(1-cos(m*k/Ncy))*cos(m*k));
   z0(5*m-2,1)=kw1*z0(5*m-4,1);
   z0(5*m-1,1)=kw1*z0(5*m-3,1);
   z0(5*m,1)=kw1*varphi*z0(5*m-4,1);
end

opts = odeset('RelTol',1e-6,'AbsTol',1e-6);
[t,z]=ode45(@one_sys_non_res_sweep,tspan,z0,opts);

filezname=[filename,'\time_matrix\timeresponse',num2str(k),'.mat'];
 save(filezname,'z');

 
 ss=0;
zz=zeros(length(tspan),s);
for sss=1:5:s*5
    ss=ss+1;
    zz(:,ss)=z(:,sss);
    zzabs(:,ss)=z(:,sss+2)-z(:,sss);
    zzpower(:,ss)=z(:,sss+4);
end

% zz1=zz;
% zz= imresize(zz,[length(z) 1000],'lanczos2');
% filezzname=[filename,'\displacement_only\displacement',num2str(k),'.mat'];
%  save(filezzname,'zz','zzabs','zzpower');
%  
t=t;%(3*maxx/step/4:end);
T=t(2)-t(1);
Fs=1/T;
L=(length(t)-1)*2;
Fn=2;
Ln=s*4*2;
f = Fs*(0:floor(L/2)-1)/L;
fn=Fn*(0:floor(Ln/2/2)-1)/Ln;
f=f;
Y=fft2(zz,L,Ln);
YY=2*Y(2:floor(L/2+1),2:floor(Ln/2+1));
% YY1=YY(:,1:1000);
% YY2=(YY(:,1001:end))';
% YY2=(flip(YY2,1))';
% YY=YY1+YY2;
% fileYname=[filename,'\2dfft\freq_resp_',num2str(k),'.mat'];
%  save(fileYname,'f','fn','YY');
[M,I] = max(abs(YY(:)));

[I_row, I_col] = ind2sub(size(abs(YY)),I);

wav=wav+1
%YYY(wav,:,:)=YY;
%mm(wav,:,:)=zz;
nonfreq(wav)=f(I_row)*2*pi;
nonwav(wav)=fn(I_col)*2*pi;
freq(wav)=w;
toc
end
% save([filename,'\disp_char1.mat'],'nonwav','nonfreq','freq')

beep
