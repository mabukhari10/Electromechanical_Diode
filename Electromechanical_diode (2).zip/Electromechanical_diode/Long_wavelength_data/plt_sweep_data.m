clear all
clc
load('G:\My Drive\IDETC2020\Extend\Long_wavelength_data\out_0_03s_0_0_f_up_var_long_r.mat');
trans_F=Eout./Ein;
load('G:\My Drive\IDETC2020\Extend\Long_wavelength_data\out_0_03s_0_0_f_up_var_long_bk.mat');
trans_B=Ein./Eout;
Eff=trans_F./trans_B;
fig_name='Long_out_0_03s_0_0_f_up_var';
w=1.41:0.02:1.6;
figure;colormap(jet);
imagesc(up_lim,w,Eff)
set(gca,'ColorScale','log')
axis xy; 
set(gca,'TickLabelInterpreter','latex')
xlabel('Upper bandgap limit', 'FontSize', 20,'interpreter','latex')
ylabel('$\omega$', 'FontSize', 20,'interpreter','latex')

h=colorbar
h.Label.String = '$\sigma$';
h.Label.Interpreter = 'latex';
h.TickLabelInterpreter='latex'
% colorbar('TickLabelInterpreter','latex');
caxis([10^5 10^8])
savefig([fig_name])