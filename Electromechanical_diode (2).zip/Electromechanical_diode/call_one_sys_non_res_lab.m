clear all
clc
tic
global w elam elam1  theta R Cp
w=1.5;
theta=171e-8*1e0;
Cp=13.3e-9*1;
R=1e7;
s=500;
elam=-0.06*0;
elam1=0.03*1;
%maxx=20000;

    maxx=1600/1;

wd=1000;

step=0.25;
tspan=0:step:maxx;

z0=zeros(5*s,1);
opts = odeset('RelTol',1e-8,'AbsTol',1e-8);
[t,z]=ode45(@one_sys_non_res_lab_n,tspan,z0,opts);

powerin=z(:,5).^2/R;
powerout=z(:,2500).^2/R;
Ein=trapz(t(1:end)/1000,powerin(1:end));
Eout=trapz(t(1:end)/1000,powerout(1:end));

Pin=(z(:,1)-1*z(:,6)+0.06*(z(:,1)-1*z(:,6)).^3).*z(:,2);
Pout=1.2939*(z(:,2496)-1*z(:,2491)).*z(:,2497);
Ei=trapz(t/1000,Pin);
Eo=trapz(t/1000,Pout);
% figure
% vmax=max(z(:,5));
% plot(t,z(:,5)/vmax)
% hold on
% plot(t,z(:,end)/vmax)
% set(gca,'TickLabelInterpreter','latex')
% xlabel('time(ms)', 'FontSize', 20,'interpreter','latex')
% ylabel('Normalized Voltage', 'FontSize', 14,'interpreter','latex')

figure
vmax=max(z(:,end));
plot(t,z(:,end)/vmax,'b', 'LineWidth',2)
hold on
plot(t,z(:,5)/vmax,'r', 'LineWidth',2)
set(gca,'TickLabelInterpreter','latex')
xlabel('time(ms)','FontSize', 20,'interpreter','latex')
ylabel('Normalized Voltage', 'FontSize', 20,'interpreter','latex')
legend('Input Voltage', 'Output Voltage')
toc