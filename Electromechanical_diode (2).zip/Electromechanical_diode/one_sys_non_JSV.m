function dz= one_sys_non_JSV(t,z)
global w elam 
s=1*500;
m=1;
Ncy=60;
t

dz(4*s,1)=zeros;
if t>1000
    Cmax=0.001
else
Cmax=0*0.001e-5;%2.75/1000;
end
c(1)=0;

         kb=1;
wn=1e3;%*sqrt(1.2939);
wd=1e3;
k1=wn^2;
k=k1;
kr1b=1.2939;
kr2b=0.1643;
ml2b=0.0397;

for n=1:s
    c(n+1)=Cmax*(abs(500-n)/s)^3;
    if n==1
     
         dz(4*n-3)=z(4*n-2);
    dz(4*n-2)=-wd^2*(z(4*n-3)-z(4*(n+1)-3)+elam*...
        ((z(4*n-3)-z(4*(n+1)-3))^3)+...
        kb*(z(4*n-3)-z(4*(n)-1))+c(n)*(z(4*n-2))+...
        c(n+1)*(z(4*n-2)-z(4*(n+1)-2)))+...
        wd^2*0.5*(heaviside(t)-...
        heaviside(t-2*pi*wn/wd/w*Ncy)).*(1-cos(wd*w/wn/Ncy*t)).*sin(wd*w/wn*t);
    dz(4*n-1)=z(4*n);
    dz(4*n)=wd^2*(z(4*n-3)-z(4*(n)-1));
    
    elseif n<350
        
        
        
    dz(4*n-3)=z(4*n-2);
    dz(4*n-2)=-wd^2*(2*z(4*n-3)-z(4*(n+1)-3)-z(4*(n-1)-3)+elam*...
        ((z(4*n-3)-z(4*(n+1)-3))^3+(z(4*n-3)-z(4*(n-1)-3))^3)+...
        kb*(z(4*n-3)-z(4*(n)-1))+c(n)*(z(4*n-2)-z(4*(n-1)-2))+...
        c(n+1)*(z(4*n-2)-z(4*(n+1)-2)));
    dz(4*n-1)=z(4*n);
    dz(4*n)=wd^2*(z(4*n-3)-z(4*(n)-1));
    elseif n==350
      
    dz(4*n-3)=z(4*n-2);
    dz(4*n-2)=-wd^2*(z(4*n-3)-z(4*(n+1)-3)+kr1b*(z(4*n-3)-z(4*(n-1)-3))+elam*...
        (0*(z(4*n-3)-z(4*(n+1)-1))^3+(z(4*n-3)-z(4*(n-1)-1))^3)+...
        kr2b*(z(4*n-3)-z(4*(n)-1))+c(n)*(z(4*n-2)-z(4*(n-1)-2)));%note
    dz(4*n-1)=z(4*n);
    dz(4*n)=wd^2/ml2b*kr2b*(z(4*n-3)-z(4*(n)-1));
    
    
    elseif n==s
        
       
        dz(4*n-3)=z(4*n-2);
    dz(4*n-2)=-wd^2*(kr1b*(z(4*n-3)-z(4*(n-1)-3))+...
        kr2b*(z(4*n-3)-z(4*(n)-1))+c(n)*(z(4*n-2)-z(4*(n-1)-2))+...
        c(n+1)*(z(4*n-2)))+0*0.5*(heaviside(t)-...
        heaviside(t-2*pi*wn/wd/w*Ncy)).*(1-cos(wd*w/wn/Ncy*t)).*sin(wd*w/wn*t);
    dz(4*n-1)=z(4*n);
    dz(4*n)=wd^2*(kr2b/ml2b*(z(4*n-3)-z(4*(n)-1)));
    
    else
        
        dz(4*n-3)=z(4*n-2);
    dz(4*n-2)=-wd^2*(kr1b*(2*z(4*n-3)-z(4*(n+1)-3)-z(4*(n-1)-3))+...
        kr2b*(z(4*n-3)-z(4*(n)-1))+c(n)*(z(4*n-2)-z(4*(n-1)-1))+...
        c(n+1)*(z(4*n-2)-z(4*(n+1)-2)));
    dz(4*n-1)=z(4*n);
    dz(4*n)=wd^2*(kr2b/ml2b*(z(4*n-3)-z(4*(n)-1)));
    end
end
end 